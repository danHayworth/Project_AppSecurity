from django.apps import AppConfig


class FlashaspieConfig(AppConfig):
    name = 'flashAsPie'
