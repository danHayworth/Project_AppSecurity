
 # Kitchen Inventory Management Application
  D & J Tech Solutions

# Project type

  Web Application

# Purpose

  This project was created as a tool for Flash as Pies, Gourmet Pie Restaurant. This Web Application fulfills the needs of the owner and staff. 
  
# Function

  Inventory: allows users to modify inventory levels throughout the day rather than doing a stock take all in one day.
  
  Ordering: Items can be added to a group order throughout the week and then sent directly to the supplier. 
  
  Staff management: Employee records are held and accessible by authorized admin accounts. 
  
# Backlog

  Product quantities added to orders will automatically update the stock when the order is delivered. 
  
# Technologies used

  Python
  Django Framework
  HTML
  Bootstrap
  CSS
  SQLite
  
 
